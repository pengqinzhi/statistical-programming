package edu.heinz.ds.androidinterestingpicture;

/*
 * @author Qinzhi Peng, qinzhip
 */

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import androidx.annotation.RequiresApi;

/*
 * This class requires input from the user, and then makes an HTTP GET request to the web service on Heroku.
 * After receiving and parsing an XML formatted reply from the web service, the andoid application will
 * displays a related picture to the user.
 *
 * The bulk of this part take lab 8 as a reference
 *
 */
public class GetPicture {
    InterestingPicture ip = null;   // for callback
    String searchTerm = null;       // search a picture for this word
    Bitmap picture = null;          // returned from the web service

    // search( )
    // Parameters:
    // String searchTerm: the thing to search for on flickr
    // Activity activity: the UI thread activity
    // InterestingPicture ip: the callback method's class; here, it will be ip.pictureReady( )
    public void search(String searchTerm, Activity activity, InterestingPicture ip) {
        this.ip = ip;
        this.searchTerm = searchTerm;
        new BackgroundTask(activity).execute();
    }

    // class BackgroundTask
    // Implements a background thread for a long running task that should not be
    //    performed on the UI thread. It creates a new Thread object, then calls doInBackground() to
    //    actually do the work. When done, it calls onPostExecute(), which runs
    //    on the UI thread to update some UI widget (***never*** update a UI
    //    widget from some other thread!)
    //
    // Adapted from one of the answers in
    // https://stackoverflow.com/questions/58767733/the-asynctask-api-is-deprecated-in-android-11-what-are-the-alternatives
    // Modified by Barrett
    //
    // Ideally, this class would be abstract and parameterized.
    // The class would be something like:
    //      private abstract class BackgroundTask<InValue, OutValue>
    // with two generic placeholders for the actual input value and output value.
    // It would be instantiated for this program as
    //      private class MyBackgroundTask extends BackgroundTask<String, Bitmap>
    // where the parameters are the String url and the Bitmap image.
    //    (Some other changes would be needed, so I kept it simple.)
    //    The first parameter is what the BackgroundTask looks up on Flickr and the latter
    //    is the image returned to the UI thread.
    // In addition, the methods doInBackground() and onPostExecute( ) could be
    //    absttract methods; would need to finesse the input and ouptut values.
    // The call to activity.runOnUiThread( ) is an Android Activity method that
    //    somehow "knows" to use the UI thread, even if it appears to create a
    //    new Runnable.

    private class BackgroundTask {

        private Activity activity; // The UI thread

        public BackgroundTask(Activity activity) {
            this.activity = activity;
        }

        private void startBackground() {
            new Thread(new Runnable() {
                public void run() {

                    doInBackground();
                    // This is magic: activity should be set to MainActivity.this
                    //    then this method uses the UI thread
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            onPostExecute();
                        }
                    });
                }
            }).start();
        }

        private void execute() {
            // There could be more setup here, which is why
            //    startBackground is not called directly
            startBackground();
        }

        // doInBackground( ) implements whatever you need to do on
        //    the background thread.
        // Implement this method to suit your needs
        private void doInBackground() {
            picture = search(searchTerm);
        }

        // onPostExecute( ) will run on the UI thread after the background
        //    thread completes.
        // Implement this method to suit your needs
        public void onPostExecute() {
            ip.pictureReady(picture);
        }

        /*
         * Sent an HTTP request to the web service with the searchTerm argument,
         * and then get the url of a picture returned from the web service
         * and return a Bitmap that can be put in an ImageView
         */
        private Bitmap search(String searchTerm) {

            // Debugging:
            System.out.println("Search, searchTerm = " + searchTerm);

            // The web service returns a Json response.
            String apitUrl = "https://guarded-cliffs-96070.herokuapp.com/getAnInterestingPicture?searchWord=" + searchTerm;

            // At this point, we have the URL of the picture that resulted from the search.  Now load the image itself.
            try {
                URL pictureURL = new URL(getRemoteTxt(apitUrl));
                // Debugging:
                System.out.println(pictureURL);
                return getRemoteImage(pictureURL);
            } catch (Exception e) {
                e.printStackTrace();
                return null; // so compiler does not complain
            }

        }


        /*
         * Sent an HTTP request to the web service,
         * and parse the response and extracts the url from the web service
         */
        private String getRemoteTxt(String url) {
            HttpURLConnection connection = null;
            InputStream is = null;
            try {
                connection = (HttpURLConnection) (new URL(url)).openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                // Read the response
                StringBuffer buffer = new StringBuffer();
                is = connection.getInputStream();
                // isolate the image from the response using regex
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                String imgRegex = "<[iI][mM][gG][^>]+[sS][rR][cC]\\s*=\\s*['\"]([^'\"]+)['\"][^>]*>";

                String line = null;
                Pattern p = Pattern.compile(imgRegex);
                while ((line = br.readLine()) != null) {
                    System.out.print(line + "\r\n");
                    for (Matcher m = p.matcher(line); m.find();) {
                        // remove the code before the image link and then return the url
                        String sub1 = line.replaceAll("<[iI][mM][gG][^>]+[sS][rR][cC]\\s*=\\s*['\"]", "");
                        String sub2 = sub1.replaceAll("\"><br><br>", "");
                        String pictureURL = sub2.trim();
                        System.out.print("pictureURL: " + pictureURL);
                        return pictureURL;
                    }
                }
                is.close();
                connection.disconnect();

                return null;
            } catch (Exception e) {
                System.out.print("Yikes, hit the error: " + e);
                return null;
            }
        }

        /*
         * Given a URL referring to an image, return a bitmap of that image
         */
        @RequiresApi(api = Build.VERSION_CODES.P)
        private Bitmap getRemoteImage(final URL url) {
            try {
                final URLConnection conn = url.openConnection();
                conn.connect();
                BufferedInputStream bis = new BufferedInputStream(conn.getInputStream());
                Bitmap bm = BitmapFactory.decodeStream(bis);
                return bm;
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }
    }
}

